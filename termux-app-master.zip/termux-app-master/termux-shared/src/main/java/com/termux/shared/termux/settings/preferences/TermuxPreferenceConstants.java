package com.termux.shared.termux.settings.preferences;

public final class TermuxPreferenceConstants {

    private TermuxPreferenceConstants() {}

    public static final String KEY_TEXT_SIZE = "text_size";
    public static final String KEY_FONT_PATH = "font_path";
    public static final String KEY_COLOR_SCHEME_PATH = "color_scheme_path";
    public static final String KEY_FULLSCREEN_MODE = "fullscreen_mode";
    public static final String KEY_USE_BLACK_UI = "use_black_ui";
    
    // ---- नए वेरिएबल्स जो हमने बैकग्राउंड फोटो के लिए जोड़े हैं ----
    public static final String KEY_CUSTOM_BACKGROUND_IMAGE_PATH = "custom_background_image_path";
    public static final String KEY_BACKGROUND_IMAGE_OPACITY = "background_image_opacity";
}
