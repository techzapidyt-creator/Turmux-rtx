package com.termux.app.fragments.settings.termux;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Toast;
import androidx.annotation.Nullable;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.PreferenceManager;
import com.termux.R;
import com.termux.shared.termux.settings.preferences.TermuxPreferenceConstants;

public class TerminalViewPreferencesFragment extends PreferenceFragmentCompat {

    private static final int REQUEST_CODE_PICK_BG = 9001;
    private SharedPreferences mSharedPreferences;

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        setPreferencesFromResource(R.xml.termux_terminal_view_preferences, rootKey);
        Context context = getContext();
        if (context == null) return;

        mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);

        Preference pickBgPref = findPreference("custom_bg_picker");
        if (pickBgPref != null) {
            pickBgPref.setOnPreferenceClickListener(preference -> {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, REQUEST_CODE_PICK_BG);
                return true;
            });
        }

        Preference removeBgPref = findPreference("custom_bg_remove");
        if (removeBgPref != null) {
            removeBgPref.setOnPreferenceClickListener(preference -> {
                mSharedPreferences.edit().putString(TermuxPreferenceConstants.KEY_CUSTOM_BACKGROUND_IMAGE_PATH, "").apply();
                Toast.makeText(context, "बैकग्राउंड वॉलपेपर हटा दिया गया है", Toast.LENGTH_SHORT).show();
                return true;
            });
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_PICK_BG && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            Uri selectedImageUri = data.getData();
            String realPath = getRealPathFromURI(selectedImageUri);
            if (realPath != null && !realPath.isEmpty()) {
                mSharedPreferences.edit().putString(TermuxPreferenceConstants.KEY_CUSTOM_BACKGROUND_IMAGE_PATH, realPath).apply();
                Toast.makeText(getContext(), "फोटो सेट हो गई! टर्मक्स रीस्टार्ट करें।", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "इमेज पाथ लोड करने में विफल!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private String getRealPathFromURI(Uri contentUri) {
        String result = null;
        Context context = getContext();
        if (context == null) return null;
        String[] proj = { MediaStore.Images.Media.DATA };
        Cursor cursor = context.getContentResolver().query(contentUri, proj, null, null, null);
        if (cursor != null) {
            if (cursor.moveToFirst()) {
                int column_index = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                result = cursor.getString(column_index);
            }
            cursor.close();
        }
        return result;
    }
}
